Autor: Jhoser Daniel Briceño Higuera

# 🚴 Página de Ciclismo

Este es un proyecto web sencillo que muestra información sobre las tres grandes vueltas de ciclismo: **Tour de Francia, Giro de Italia y Vuelta a España**.

## 📂 Estructura del Proyecto

Pagina ciclismo/
│── index.html        # Página principal de inicio
│── tour.html         # Página del Tour de Francia
│── giro.html         # Página del Giro de Italia
│── vuelta.html       # Página de la Vuelta a España
│
│── css/
│   └── styles.css    # Estilos principales del sitio
│
│── img/              # Imágenes utilizadas en el sitio
│  
│   ├── alberto_contador.jpg
│   ├── alfredo_binda.jpg
│   ├── alpe_arrivee.jpg
│   ├── angliru_climb.jpeg
│   ├── armstrong_tdf2004.jpg
│   ├── bernard_hinault.jpg
│   ├── bicicleta_tecnologia.jpg
│   ├── champs_elysees.jpg
|   ├── Cicla.png
│   ├── eddy_merckx.jpg
│   ├── estrategia_equipo.jpg
│   ├── fondo_index.jpg
│   ├── fondo_tour.jpg
│   ├── fondo-giro.avif
│   ├── fondo-vuelta1.jpeg
│   ├── gino_bartali.jpg
│   ├── giro_dolomitas.jpg
│   ├── giro_podium.jpg
│   ├── giro_pogacar.jpg
│   ├── giro.png
│   ├── heras_vuelta.jpg
│   ├── maillot_rojo.webp
│   ├── marco_pantali.jpg
│   ├── pogacar_podium.jpg
│   ├── roberto_heras.jpg
│   ├── roglich_podium.jpg
│   ├── sierra_nevada.jpg
│   ├── tour.png
│   ├── vuelta.png
│
└── README.md         # Documentación del proyecto


