// models/index.js
const Ubicacion = require('./Ubicacion');
const { Equipo } = require('./Equipo');
const { Mantenimiento } = require('./Mantenimiento');
const personas_mantenimiento = require('./personas_mantenimiento');
const responsables_custodios = require('./responsables_custodios');

// Ubicación 1..N Equipos
Ubicacion.hasMany(Equipo, { foreignKey: 'ubicacionId' });
Equipo.belongsTo(Ubicacion, { foreignKey: 'ubicacionId' });

// Responsable 1..N Equipos
responsables_custodios.hasMany(Equipo, { foreignKey: 'responsableId' });
Equipo.belongsTo(responsables_custodios, { foreignKey: 'responsableId' });

// Equipo 1..N Mantenimientos
Equipo.hasMany(Mantenimiento, { foreignKey: 'equipoId', onDelete: 'CASCADE' });
Mantenimiento.belongsTo(Equipo, { foreignKey: 'equipoId' });

// Persona 1..N Mantenimientos (responsable que ejecuta el mantenimiento)
personas_mantenimiento.hasMany(Mantenimiento, { foreignKey: 'responsableId' });
Mantenimiento.belongsTo(personas_mantenimiento, { foreignKey: 'responsableId' });

module.exports = { Ubicacion, responsables_custodios, Equipo, Mantenimiento, personas_mantenimiento };
