// models/Equipo.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../db');

const TIPOS = ['laptop', 'desktop', 'impresora', 'switch', 'router', 'servidor', 'otro'];
const ESTADOS = ['operativo', 'en_mantenimiento', 'dado_de_baja'];

const Equipo = sequelize.define('Equipo', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  codigo_inventario: { type: DataTypes.STRING(60), allowNull: false, unique: true },
  serial: { type: DataTypes.STRING(100), unique: true, allowNull: true },
  marca: { type: DataTypes.STRING(100) },
  modelo: { type: DataTypes.STRING(100) },
  tipo_equipo: { type: DataTypes.ENUM(...TIPOS), allowNull: false, defaultValue: 'otro' },
  estado: { type: DataTypes.ENUM(...ESTADOS), allowNull: false, defaultValue: 'operativo' },

  // Relaciones
  ubicacionId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  responsableId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
}, {
  tableName: 'equipos',
  timestamps: true,
});

module.exports = { Equipo, TIPOS, ESTADOS };
