// models/responsables_custodios.js   equivale a las áreas responsables de custoria de equipos
const { DataTypes } = require('sequelize');
const { sequelize } = require('../db');

// Campos solicitados: id, id_area, nombre_area
const responsables_custodios = sequelize.define('responsables_custodios', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  id_area: { type: DataTypes.STRING(50), allowNull: false, unique: true }, // código de área (único)
  nombre_area: { type: DataTypes.STRING(120), allowNull: false },
}, {
  tableName: 'responsables_custodios',
  timestamps: true,
});

module.exports = responsables_custodios;
