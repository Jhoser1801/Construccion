// public/productos.js 
const API = '/api/productos';
const API_OPC = '/api/opciones'; //endpoint para ENUMs; 

const tbody = document.getElementById('tbody');
const btnNuevo = document.getElementById('btnNuevo');

const prodModal = new bootstrap.Modal(document.getElementById('prodModal'));
const form = document.getElementById('formProd');
const modalTitle = document.getElementById('modalTitle');

const $id = document.getElementById('id');
const $nombre = document.getElementById('nombre');
const $precio = document.getElementById('precio');
const $categoria = document.getElementById('categoria');
const $condicion = document.getElementById('condicion');

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return alert(message);
  const bg = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role = 'alert'; el.ariaLive = 'assertive'; el.ariaAtomic = 'true';
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 3000 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

async function cargarOpciones() {
  // $categoria.innerHTML  = categorias.map(v  => `<option value="${v}">${v}</option>`).join('');
  // $condicion.innerHTML  = condiciones.map(v => `<option value="${v}">${v[0].toUpperCase()+v.slice(1)}</option>`).join('');
  try {
    const res = await fetch(API_OPC);
    if (!res.ok) throw new Error('No se pudieron cargar las opciones');
    const { categorias, condiciones } = await res.json();
    $categoria.innerHTML  = categorias.map(v  => `<option value="${v}">${v}</option>`).join('');
    $condicion.innerHTML  = condiciones.map(v => `<option value="${v}">${v[0].toUpperCase() + v.slice(1)}</option>`).join('');
  } catch (err) {
    showToast('Error cargando catálogos.', 'error');
    // Opcional: fallback local
    const categorias = ['Equipo IT', 'Equipo biomédico'];
    const condiciones = ['nuevo', 'usado'];
    $categoria.innerHTML  = categorias.map(v  => `<option value="${v}">${v}</option>`).join('');
    $condicion.innerHTML  = condiciones.map(v => `<option value="${v}">${v[0].toUpperCase()+v.slice(1)}</option>`).join('');
  }
}

async function listar() {
  try {
    const res = await fetch(API);
    if (!res.ok) throw new Error('No se pudo listar');
    const data = await res.json();
    renderTabla(data);
  } catch (err) {
    showToast('Error al listar productos.', 'error');
  }
}

function renderTabla(items) {
  tbody.innerHTML = '';
  items.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${p.nombre}</td>
      <td class="text-end">$ ${Number(p.precio).toFixed(2)}</td>
      <td>${p.categoria}</td>
      <td>${p.condicion}</td>
      <td>${p.createdAt ?? ''}</td>
      <td>${p.updatedAt ?? ''}</td>
      <td>
        <button class="btn btn-sm btn-warning me-2" data-action="edit" data-id="${p.id}">Editar</button>
        <button class="btn btn-sm btn-danger"  data-action="del"  data-id="${p.id}">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

tbody.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.action;

  if (action === 'edit') {
    try {
      const res = await fetch(`${API}/${id}`);
      if (!res.ok) throw new Error('No se pudo cargar el producto');
      const p = await res.json();
      modalTitle.textContent = `Editar producto #${p.id}`;
      $id.value = p.id;
      $nombre.value = p.nombre;
      $precio.value = p.precio;
      $categoria.value = p.categoria;
      $condicion.value = p.condicion;
      prodModal.show();
    } catch (err) { showToast('Error cargando el producto.', 'error'); }
  } else if (action === 'del') {
    if (!confirm('¿Eliminar este producto?')) return;
    try {
      const res = await fetch(`${API}/${id}`, { method: 'DELETE' });
      if (res.ok) { await listar(); showToast('Producto eliminado', 'info'); }
      else { const err = await res.json().catch(()=>({})); showToast(err.error || 'No se pudo eliminar.', 'error'); }
    } catch (err) { showToast('Error eliminando el producto.', 'error'); }
  }
});

btnNuevo.addEventListener('click', () => {
  modalTitle.textContent = 'Nuevo producto';
  form.reset(); $id.value = '';
  if ($categoria.options.length) $categoria.selectedIndex = 0;
  if ($condicion.options.length) $condicion.selectedIndex = 0;
  prodModal.show();
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    nombre: $nombre.value.trim(),
    precio: parseFloat($precio.value),
    categoria: $categoria.value,
    condicion: $condicion.value,
  };
  if (!payload.nombre || isNaN(payload.precio) || !payload.categoria || !payload.condicion) {
    return showToast('Completa todos los campos correctamente.', 'error');
  }
  const isEdit = Boolean($id.value);
  const url = isEdit ? `${API}/${$id.value}` : API;
  const method = isEdit ? 'PUT' : 'POST';

  try {
    const res = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
    });
    if (res.ok) {
      prodModal.hide(); await listar();
      showToast(isEdit ? 'Producto actualizado con éxito' : 'Producto creado con éxito', 'success');
    } else {
      const err = await res.json().catch(()=>({})); showToast(err.error || 'Error al guardar.', 'error');
    }
  } catch (err) { showToast('Error al guardar.', 'error'); }
});

cargarOpciones().then(listar).catch(()=>{});
