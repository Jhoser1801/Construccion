const API = '/api/personas_mantenimiento';
const tbody = document.getElementById('tbody');
const btnNuevo = document.getElementById('btnNuevo');
const modal = new bootstrap.Modal(document.getElementById('modal'));
const $ = (id)=>document.getElementById(id);

function showToast(message, type='success'){
  const container = document.getElementById('toastContainer');
  const bg = type==='success'?'bg-success':type==='error'?'bg-danger':'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role='alert'; el.ariaLive='assertive'; el.ariaAtomic='true';
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  container.appendChild(el);
  const t=new bootstrap.Toast(el,{delay:2800}); t.show();
  el.addEventListener('hidden.bs.toast', ()=>el.remove());
}

async function fetchJSON(url, opts){ const r=await fetch(url,opts); if(!r.ok) throw new Error(await r.text().catch(()=>'')); return r.json(); }

async function listar(){
  const data = await fetchJSON(API);
  tbody.innerHTML = '';
  data.forEach(p=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${p.identificacion}</td>
      <td>${p.nombres}</td>
      <td>${p.apellidos}</td>
      <td>${p.cargo||''}</td>
      <td>${p.email||''}</td>
      <td>${p.telefono||''}</td>
      <td>${p.createdAt||''}</td>
      <td>${p.updatedAt||''}</td>
      <td>
        <button class="btn btn-sm btn-warning me-2" data-act="edit" data-id="${p.id}">Editar</button>
        <button class="btn btn-sm btn-danger" data-act="del" data-id="${p.id}">Eliminar</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

btnNuevo.addEventListener('click', ()=>{
  $('title').textContent = 'Nueva persona';
  $('id').value=''; $('identificacion').value=''; $('nombres').value=''; $('apellidos').value='';
  $('cargo').value=''; $('email').value=''; $('telefono').value='';
  modal.show();
});

tbody.addEventListener('click', async (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  const {act,id} = btn.dataset;
  if (act==='edit'){
    const items = await fetchJSON(API);
    const it = items.find(x=>x.id==id);
    if(!it) return showToast('No encontrada','error');
    $('title').textContent = `Editar persona #${id}`;
    $('id').value=id; $('identificacion').value=it.identificacion; $('nombres').value=it.nombres;
    $('apellidos').value=it.apellidos; $('cargo').value=it.cargo||''; $('email').value=it.email||'';
    $('telefono').value=it.telefono||'';
    modal.show();
  } else if (act==='del'){
    if(!confirm('¿Eliminar persona?')) return;
    try{
      await fetchJSON(`${API}/${id}`, { method:'DELETE' });
      await listar(); showToast('Persona eliminada','info');
    }catch(e){ showToast('No se pudo eliminar','error'); }
  }
});

document.getElementById('form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const payload = {
    identificacion: $('identificacion').value.trim(),
    nombres: $('nombres').value.trim(),
    apellidos: $('apellidos').value.trim(),
    cargo: $('cargo').value.trim() || null,
    email: $('email').value.trim() || null,
    telefono: $('telefono').value.trim() || null,
  };
  const id = $('id').value;
  try{
    if (id) await fetchJSON(`${API}/${id}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    else await fetchJSON(API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    modal.hide(); await listar(); showToast(id?'Persona actualizada':'Persona creada');
  }catch{ showToast('Error al guardar','error'); }
});

listar().catch(()=>showToast('Error al listar','error'));
