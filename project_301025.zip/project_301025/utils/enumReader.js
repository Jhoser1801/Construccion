// utils/enumReader.js  sirve para leer los valores de un ENUM en MySQL
const { sequelize } = require('../db');  // instancia de Sequelize

async function readEnumValues(table, column) { // async quiere decir una promesa, equivale a una función asíncrona
  const dbName = sequelize.getDatabaseName(); // obtiene el nombre de la base de datos actual
  const [rows] = await sequelize.query(       // consulta directa a la base de datos
    `SELECT COLUMN_TYPE
       FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    { replacements: [dbName, table, column] }
  );
  if (!rows.length) return [];
  // COLUMN_TYPE: "enum('Equipo IT','Equipo biomédico', ...)"
  const m = rows[0].COLUMN_TYPE.match(/^enum\((.*)\)$/i);
  if (!m) return [];
  return m[1]
    .split(',')  // separa por comas
    .map(s => s.trim().replace(/^'(.*)'$/, '$1')); // quita comillas
}

module.exports = { readEnumValues }; // exporta la función denominada readEnumValues para usar en server.js
