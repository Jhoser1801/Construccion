// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

const { sequelize } = require('./db');
const Product = require('./models/Product');
const { readEnumValues } = require('./utils/enumReader');

const app = express();

/* ===============================
 *  Configuración de vistas / estáticos
 * =============================== */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(cors());
app.use(express.json());

// Public (js, css, imágenes…)
app.use(express.static('public'));

// Carpeta de uploads segura
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use('/uploads', express.static(UPLOAD_DIR, {
  setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff')
}));

/* ===============================
 *  Multer (uploads)
 * =============================== */
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${uuidv4()}${ext}`);
  }
});
const ALLOWED = ['application/pdf', 'image/png', 'image/jpeg'];
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED.includes(file.mimetype)) {
      return cb(new Error('Tipo de archivo no permitido. Usa PDF/JPG/PNG.'));
    }
    cb(null, true);
  }
});

// Endpoint de subida
app.post('/api/uploads', upload.single('file'), (req, res) => {
  try {
    const relUrl = `/uploads/${req.file.filename}`;
    return res.status(201).json({
      ok: true,
      url: relUrl,
      original: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype
    });
  } catch (e) {
    return res.status(400).json({ ok: false, error: e.message });
  }
});


/* ===============================
 *  Helpers de DTO / Fechas Bogotá
 * =============================== */
function fmtBogota(date) {
  return new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(date));
}
function toDTO(entity) {
  const obj = entity?.toJSON ? entity.toJSON() : { ...entity };
  if (obj.createdAt) obj.createdAt = fmtBogota(obj.createdAt);
  if (obj.updatedAt) obj.updatedAt = fmtBogota(obj.updatedAt);
  if (obj.fecha_programada) obj.fecha_programada = fmtBogota(obj.fecha_programada);
  if (obj.fecha_ejecucion) obj.fecha_ejecucion = fmtBogota(obj.fecha_ejecucion);
  if (obj.proximo_vencimiento) obj.proximo_vencimiento = fmtBogota(obj.proximo_vencimiento);
  return obj;
}

/* ===============================
 *  Importar modelos de dominio
 * =============================== */
const { Op } = require('sequelize');
const { Ubicacion, responsables_custodios, Equipo, Mantenimiento, personas_mantenimiento } = require('./models');
const {
  TIPOS: MT_TIPOS,
  PRIORIDADES: MT_PRIORIDADES,
  RESULTADOS: MT_RESULTADOS
} = require('./models/Mantenimiento');

const isValidEnum = (val, arr) => (val == null || val === '' ? true : arr.includes(val));
const isISOorNull = (v) => !v || !Number.isNaN(Date.parse(v));

/* ===============================
 *  APIs — Productos (demo)
 * =============================== */
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.get('/api/productos', async (_req, res) => {
  try {
    const productos = await Product.findAll({ order: [['id', 'ASC']] });
    res.json(productos.map(toDTO));
  } catch (err) {
    res.status(500).json({ error: 'Error al listar productos' });
  }
});

app.get('/api/productos/:id', async (req, res) => {
  const prod = await Product.findByPk(req.params.id);
  if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json(toDTO(prod));
});

app.post('/api/productos', async (req, res) => {
  try {
    const { nombre, precio, categoria, condicion } = req.body;
    if (!nombre || precio == null || !categoria || !condicion) {
      return res.status(400).json({ error: 'Faltan campos obligatorios' });
    }
    const nuevo = await Product.create({ nombre, precio, categoria, condicion });
    res.status(201).json(toDTO(nuevo));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/productos/:id', async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });
    const { nombre, precio, categoria, condicion } = req.body;
    await prod.update({ nombre, precio, categoria, condicion });
    res.json(toDTO(prod));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/productos/:id', async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });
    await prod.destroy();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ===============================
 *  APIs — Personas
 * =============================== */
app.get('/api/personas_mantenimiento', async (req, res) => {
  try {
    const { q } = req.query;
    const where = q
      ? {
          [Op.or]: [
            { identificacion: { [Op.like]: `%${q}%` } },
            { apellidos: { [Op.like]: `%${q}%` } },
            { nombres: { [Op.like]: `%${q}%` } }
          ]
        }
      : {};
    const items = await personas_mantenimiento.findAll({
      where,
      order: [['apellidos', 'ASC'], ['nombres', 'ASC']],
      limit: 30
    });
    res.json(items.map(toDTO));
  } catch (e) {
    res.status(500).json({ error: 'Error al listar personas' });
  }
});

app.get('/api/personas_mantenimiento/:id', async (req, res) => {
  const p = await personas_mantenimiento.findByPk(req.params.id);
  if (!p) return res.status(404).json({ error: 'Persona no encontrada' });
  res.json(toDTO(p));
});

app.post('/api/personas_mantenimiento', async (req, res) => {
  try {
    const p = await personas_mantenimiento.create(req.body);
    res.status(201).json(toDTO(p));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/personas_mantenimiento/:id', async (req, res) => {
  try {
    const p = await personas_mantenimiento.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: 'Persona no encontrada' });
    await p.update(req.body);
    res.json(toDTO(p));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/personas_mantenimiento/:id', async (req, res) => {
  try {
    const hasMtto = await Mantenimiento.count({ where: { responsableId: req.params.id } });
    if (hasMtto) return res.status(400).json({ error: 'No se puede eliminar: tiene mantenimientos asociados' });
    const p = await personas_mantenimiento.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: 'Persona no encontrada' });
    await p.destroy();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ===============================
 *  APIs — Equipos (incluye /min)
 * =============================== */
app.get('/api/equipos/min', async (_req, res) => {
  try {
    const rows = await Equipo.findAll({
      attributes: ['id', 'codigo_inventario', 'marca', 'modelo'],
      order: [['codigo_inventario', 'ASC']]
    });
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Error al listar códigos' });
  }
});

app.get('/api/equipos', async (req, res) => {
  try {
    const { q, estado, tipo, ubicacionId, responsableId } = req.query;
    const where = {};
    if (estado) where.estado = estado;
    if (tipo) where.tipo_equipo = tipo;
    if (ubicacionId) where.ubicacionId = Number(ubicacionId);
    if (responsableId) where.responsableId = Number(responsableId);
    if (q) {
      where[Op.or] = [
        { codigo_inventario: q },
        { serial: { [Op.like]: `%${q}%` } },
        { marca: { [Op.like]: `%${q}%` } },
        { modelo: { [Op.like]: `%${q}%` } }
      ];
    }

    const items = await Equipo.findAll({
      where,
      include: [Ubicacion, responsables_custodios],
      order: [['id', 'ASC']]
    });
    res.json(items.map(toDTO));
  } catch (e) {
    res.status(500).json({ error: 'Error al listar equipos' });
  }
});

app.get('/api/equipos/:id', async (req, res) => {
  const item = await Equipo.findByPk(req.params.id, { include: [Ubicacion, responsables_custodios] });
  if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
  res.json(toDTO(item));
});

app.post('/api/equipos', async (req, res) => {
  try {
    const item = await Equipo.create(req.body);
    res.status(201).json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/equipos/:id', async (req, res) => {
  try {
    const item = await Equipo.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/equipos/:id', async (req, res) => {
  try {
    const item = await Equipo.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ===============================
 *  APIs — Mantenimientos (+validaciones fuertes)
 * =============================== */
app.get('/api/mantenimientos/opciones', (_req, res) => {
  res.json({ tipos: MT_TIPOS, prioridades: MT_PRIORIDADES, resultados: MT_RESULTADOS });
});

app.get('/api/mantenimientos', async (req, res) => {
  try {
    const { equipoId, tipo, prioridad, resultado, desde, hasta, q, responsableId } = req.query;
    const where = {};
    if (equipoId) where.equipoId = Number(equipoId);
    if (responsableId) where.responsableId = Number(responsableId);
    if (tipo) where.tipo = tipo;
    if (prioridad) where.prioridad = prioridad;
    if (resultado) where.resultado = resultado;
    if (q) where.descripcion = { [Op.like]: `%${q}%` };
    if (desde || hasta) {
      const r = {};
      if (desde) r[Op.gte] = new Date(desde);
      if (hasta) r[Op.lte] = new Date(hasta);
      where.fecha_programada = r;
    }
    const items = await Mantenimiento.findAll({
      where,
      include: [{ model: Equipo }, { model: personas_mantenimiento }],
      order: [['id', 'ASC']]
    });
    res.json(items.map(toDTO));
  } catch {
    res.status(500).json({ error: 'Error al listar mantenimientos' });
  }
});

app.get('/api/mantenimientos/:id', async (req, res) => {
  const it = await Mantenimiento.findByPk(req.params.id, { include: [Equipo, personas_mantenimiento] });
  if (!it) return res.status(404).json({ error: 'Mantenimiento no encontrado' });
  res.json(toDTO(it));
});

app.post('/api/mantenimientos', async (req, res) => {
  try {
    let { equipoId, codigo_inventario, responsableId, tipo, prioridad, resultado,
          fecha_programada, fecha_ejecucion, proximo_vencimiento } = req.body;

    if (!equipoId && codigo_inventario) {
      const eq = await Equipo.findOne({ where: { codigo_inventario } });
      if (!eq) return res.status(400).json({ error: 'No existe un equipo con ese código de inventario' });
      equipoId = eq.id;
    }
    if (!equipoId) return res.status(400).json({ error: 'Falta equipo (equipoId o codigo_inventario)' });

    if (!responsableId) return res.status(400).json({ error: 'Falta responsableId' });
    const exists = await personas_mantenimiento.count({ where: { id: responsableId } });
    if (!exists) return res.status(400).json({ error: 'responsableId no existe' });

    if (!isValidEnum(tipo, MT_TIPOS)) return res.status(400).json({ error: 'tipo inválido' });
    if (!isValidEnum(prioridad, MT_PRIORIDADES)) return res.status(400).json({ error: 'prioridad inválida' });
    if (!isValidEnum(resultado, MT_RESULTADOS)) return res.status(400).json({ error: 'resultado inválido' });

    if (!isISOorNull(fecha_programada) || !isISOorNull(fecha_ejecucion) || !isISOorNull(proximo_vencimiento)) {
      return res.status(400).json({ error: 'Formato de fecha inválido' });
    }

    const payload = { ...req.body, equipoId, responsableId };
    delete payload.codigo_inventario;

    const item = await Mantenimiento.create(payload);
    res.status(201).json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/mantenimientos/:id', async (req, res) => {
  try {
    const it = await Mantenimiento.findByPk(req.params.id);
    if (!it) return res.status(404).json({ error: 'Mantenimiento no encontrado' });

    let { equipoId, codigo_inventario, responsableId, tipo, prioridad, resultado,
          fecha_programada, fecha_ejecucion, proximo_vencimiento } = req.body;

    if (!equipoId && codigo_inventario) {
      const eq = await Equipo.findOne({ where: { codigo_inventario } });
      if (!eq) return res.status(400).json({ error: 'No existe un equipo con ese código de inventario' });
      equipoId = eq.id;
    }
    if (responsableId == null) return res.status(400).json({ error: 'Falta responsableId' });
    const exists = await personas_mantenimiento.count({ where: { id: responsableId } });
    if (!exists) return res.status(400).json({ error: 'responsableId no existe' });

    if (!isValidEnum(tipo, MT_TIPOS)) return res.status(400).json({ error: 'tipo inválido' });
    if (!isValidEnum(prioridad, MT_PRIORIDADES)) return res.status(400).json({ error: 'prioridad inválida' });
    if (!isValidEnum(resultado, MT_RESULTADOS)) return res.status(400).json({ error: 'resultado inválido' });

    if (!isISOorNull(fecha_programada) || !isISOorNull(fecha_ejecucion) || !isISOorNull(proximo_vencimiento)) {
      return res.status(400).json({ error: 'Formato de fecha inválido' });
    }

    const payload = { ...req.body };
    if (equipoId) payload.equipoId = equipoId;
    payload.responsableId = responsableId;
    delete payload.codigo_inventario;

    await it.update(payload);
    res.json(toDTO(it));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/mantenimientos/:id', async (req, res) => {
  try {
    const it = await Mantenimiento.findByPk(req.params.id);
    if (!it) return res.status(404).json({ error: 'Mantenimiento no encontrado' });
    await it.destroy();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ===============================
 *  APIs — Ubicaciones / Responsables
 * =============================== */
app.get('/api/ubicaciones', async (_req, res) => {
  try {
    const items = await Ubicacion.findAll({ order: [['identificacion', 'ASC']] });
    res.json(items.map(toDTO));
  } catch (e) {
    res.status(500).json({ error: 'Error al listar ubicaciones' });
  }
});

app.get('/api/ubicaciones/:id', async (req, res) => {
  const item = await Ubicacion.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
  res.json(toDTO(item));
});

app.post('/api/ubicaciones', async (req, res) => {
  try {
    const item = await Ubicacion.create(req.body);
    res.status(201).json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/ubicaciones/:id', async (req, res) => {
  try {
    const item = await Ubicacion.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/ubicaciones/:id', async (req, res) => {
  try {
    const hasEquipos = await Equipo.count({ where: { ubicacionId: req.params.id } });
    if (hasEquipos) return res.status(400).json({ error: 'No se puede eliminar: hay equipos en esta ubicación' });
    const item = await Ubicacion.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/responsables_custodios', async (_req, res) => {
  try {
    const items = await responsables_custodios.findAll({ order: [['id_area', 'ASC']] });
    res.json(items.map(toDTO));
  } catch (e) {
    res.status(500).json({ error: 'Error al listar responsables' });
  }
});

app.get('/api/responsables_custodios/:id', async (req, res) => {
  const item = await responsables_custodios.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
  res.json(toDTO(item));
});

app.post('/api/responsables_custodios', async (req, res) => {
  try {
    const item = await responsables_custodios.create(req.body); 
    res.status(201).json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/responsables_custodios/:id', async (req, res) => {
  try {
    const item = await responsables_custodios.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/responsables_custodios/:id', async (req, res) => {
  try {
    const hasEquipos = await Equipo.count({ where: { responsableId: req.params.id } });
    if (hasEquipos) return res.status(400).json({ error: 'No se puede eliminar: hay equipos asociados a este responsable' });
    const item = await responsables_custodios.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ===============================
 *  Opciones de enums (productos)
 * =============================== */
app.get('/api/opciones', async (_req, res) => {
  try {
    const categorias = await readEnumValues('productos', 'categoria');
    const condiciones = await readEnumValues('productos', 'condicion');
    res.json({ categorias, condiciones });
  } catch (e) {
    res.status(500).json({ error: 'No se pudieron leer los catálogos' });
  }
});

/* ===============================
 *  Rutas de vistas (SSR con EJS)
 * =============================== */
/* ===============================
 *  Vistas SSR
 * =============================== */
app.get('/', (_req, res) => res.render('home'));
app.get('/personas_mantenimientos', (_req, res) => res.render('personas_mantenimientos', {}));

app.get('/productos', async (_req, res) => {
  const productos = await Product.findAll({ order: [['id', 'ASC']] });
  res.render('productos', { productos: productos.map(toDTO) });
});

app.get('/equipos', async (_req, res) => {
  const equipos = await Equipo.findAll({ include: [Ubicacion, responsables_custodios], order: [['id', 'ASC']] });
  res.render('equipos', { equipos });
});

app.get('/ubicaciones', async (_req, res) => {
  const ubicaciones = await Ubicacion.findAll({ order: [['identificacion', 'ASC']] });
  res.render('ubicaciones', { ubicaciones });
});

app.get('/responsables_custodios', async (_req, res) => {
  const responsables = await responsables_custodios.findAll({ order: [['id_area', 'ASC']] });
  res.render('responsables_custodios', { responsables });
});
app.get('/mantenimientos', async (_req, res) => {
  const mantenimientos = await Mantenimiento.findAll({ include: [Equipo, personas_mantenimiento], order: [['id', 'ASC']] });
  res.render('mantenimientos', { mantenimientos: mantenimientos.map(toDTO) });
});



/* ===============================
 *  Manejo de errores de multer
 * =============================== */
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ ok: false, error: 'Archivo supera 5MB' });
    }
    return res.status(400).json({ ok: false, error: `Error de subida: ${err.code}` });
  }
  if (err && err.message && err.message.includes('Tipo de archivo no permitido')) {
    return res.status(400).json({ ok: false, error: err.message });
  }
  return res.status(500).json({ ok: false, error: err?.message || 'Error interno' });
});

/* ===============================
 *  Arranque + Seeds
 * =============================== */
const PORT = Number(process.env.PORT || 4000);

(async () => {
  try {
    await sequelize.authenticate();
    console.log('Conectado a la BD MySQL');

    await sequelize.sync();
    console.log('Tablas listas');

    // Seed productos
    const total = await Product.count();
    if (!total) {
      await Product.bulkCreate([
        { nombre: 'Router', precio: 299900, categoria: 'Equipo IT', condicion: 'nuevo' },
        { nombre: 'Portátil 15” i9', precio: 7399900, categoria: 'Equipo IT', condicion: 'nuevo' },
        { nombre: 'Bomba infusora', precio: 1299900, categoria: 'Equipo biomédico', condicion: 'usado' }
      ]);
      console.log('Seed inicial cargado (3 productos).');
    }

    // Seeds para dominio de mantenimiento de equipos
    const uCount = await Ubicacion.count();
    if (!uCount) {
      await Ubicacion.bulkCreate([
        { identificacion: 'S1-A-3-305', sede: 'Sede 1', edificio: 'A', piso: '3', sala: '305' },
        { identificacion: 'S1-D-1-101', sede: 'Sede 1', edificio: 'D', piso: '1', sala: '101' }
      ]);
    }

    const rCount = await responsables_custodios.count();
    if (!rCount) {
      await responsables_custodios.bulkCreate([
        { id_area: 'TI', nombre_area: 'Tecnologías de la Información' },
        { id_area: 'LOG', nombre_area: 'Logística' }
      ]);
    }

    const [u1] = await Ubicacion.findAll({ limit: 1 });
    const [r1] = await responsables_custodios.findAll({ limit: 1 });

    const eCount = await Equipo.count();
    if (!eCount && u1 && r1) {
      await Equipo.bulkCreate([
        {
          codigo_inventario: 'EQ-0001',
          serial: 'SN-ABC-001',
          marca: 'Dell',
          modelo: 'Latitude 5520',
          tipo_equipo: 'laptop',
          estado: 'operativo',
          ubicacionId: u1.id,
          responsableId: r1.id
        },
        {
          codigo_inventario: 'EQ-0002',
          serial: 'SN-XYZ-002',
          marca: 'HP',
          modelo: 'ProDesk 600',
          tipo_equipo: 'desktop',
          estado: 'operativo',
          ubicacionId: u1.id,
          responsableId: r1.id
        }
      ]);
    }

    const pCount = await personas_mantenimiento.count();
    if (!pCount) {
      await personas_mantenimiento.bulkCreate([
        { identificacion: '1001', apellidos: 'Pérez', nombres: 'Carlos' },
        { identificacion: '1002', apellidos: 'Pérez', nombres: 'Carlos Andrés' },
        { identificacion: '2001', apellidos: 'García', nombres: 'María' }
      ]);
    }

    const mCount = await Mantenimiento.count();
    if (!mCount) {
      const firstEquipo = await Equipo.findOne();
      let firstPersona_mantenimiento = await personas_mantenimiento.findOne();

      if (!firstPersona_mantenimiento) {
        firstPersona_mantenimiento = await personas_mantenimiento.create({
          identificacion: '0000',
          apellidos: 'Soporte',
          nombres: 'Técnico',
          email: 'soporte@demo.com'
        });
      }

      if (firstEquipo && firstPersona_mantenimiento) {
        await Mantenimiento.bulkCreate([
          {
            equipoId: firstEquipo.id,
            responsableId: firstPersona_mantenimiento.id,
            tipo: 'preventivo',
            prioridad: 'media',
            fecha_programada: new Date(),
            proximo_vencimiento: new Date(Date.now() + 1000 * 60 * 60 * 24 * 90),
            descripcion: 'Mantenimiento preventivo general (limpieza y actualización BIOS).',
            resultado: null
          },
          {
            equipoId: firstEquipo.id,
            responsableId: firstPersona_mantenimiento.id,
            tipo: 'correctivo',
            prioridad: 'alta',
            fecha_programada: new Date(),
            fecha_ejecucion: new Date(),
            descripcion: 'Reemplazo de fuente de poder.',
            resultado: 'exitoso'
          }
        ]);
        console.log('Seed de mantenimientos cargado.');
      } else {
        console.log('No se sembraron mantenimientos: faltan equipo y/o persona.');
      }
    }

    app.listen(PORT, () => {
      console.log(`Servidor listo → http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('No se pudo iniciar:', err);
    process.exit(1);
  }
})();
