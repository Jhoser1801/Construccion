const API = {
  eqp: '/api/equipos',
  man: '/api/mantenimientos',
};

const tbody = document.getElementById('tbody');
const btnNuevo = document.getElementById('btnNuevo');
const modal = new bootstrap.Modal(document.getElementById('modal'));
const $ = (id) => document.getElementById(id);

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const bg = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white ${bg} border-0`;
  el.role = 'alert';
  el.ariaLive = 'assertive';
  el.ariaAtomic = 'true';
  el.innerHTML = `<div class="d-flex">
    <div class="toast-body">${message}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
  </div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 2800 });
  t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

async function fetchJSON(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(await r.text().catch(() => ''));
  return r.json();
}

const TIPOS = ['preventivo', 'correctivo'];
const PRIORIDADES = ['baja', 'media', 'alta', 'crítica'];
const RESULTADOS = ['exitoso', 'parcial', 'fallido'];

async function loadEnumsAndCatalogs() {
  $('fTipo').innerHTML =
    '<option value="">Tipo...</option>' +
    TIPOS.map((t) => `<option value="${t}">${t}</option>`).join('');
  $('fPrioridad').innerHTML =
    '<option value="">Prioridad...</option>' +
    PRIORIDADES.map((p) => `<option value="${p}">${p}</option>`).join('');
  $('fResultado').innerHTML =
    '<option value="">Resultado...</option>' +
    RESULTADOS.map((r) => `<option value="${r}">${r}</option>`).join('');
  $('tipo').innerHTML = TIPOS.map((t) => `<option value="${t}">${t}</option>`).join('');
  $('prioridad').innerHTML = PRIORIDADES.map((p) => `<option value="${p}">${p}</option>`).join('');
  $('resultado').innerHTML = RESULTADOS.map((r) => `<option value="${r}">${r}</option>`).join('');

  // Cargar equipos
  try {
    const equipos = await fetchJSON(API.eqp);
    $('equipoId').innerHTML =
      '<option value="">Seleccione equipo...</option>' +
      equipos
        .map((e) => `<option value="${e.id}">${e.codigo_inventario} — ${e.marca} ${e.modelo}</option>`)
        .join('');
  } catch (err) {
    console.error(err);
    showToast('Error al cargar equipos', 'error');
  }
}

async function listar() {
  const params = new URLSearchParams();
  const q = $('q').value.trim();
  if (q) params.set('q', q);
  const tip = $('fTipo').value;
  if (tip) params.set('tipo', tip);
  const pri = $('fPrioridad').value;
  if (pri) params.set('prioridad', pri);
  const res = $('fResultado').value;
  if (res) params.set('resultado', res);

  const data = await fetchJSON(`${API.man}${params.toString() ? `?${params}` : ''}`);
  tbody.innerHTML = '';
  data.forEach((e) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${e.id}</td>
      <td>${e.equipoId}</td>
      <td>${e.tipo}</td>
      <td>${e.prioridad}</td>
      <td>${e.resultado}</td>
      <td>${e.fecha_programada || ''}</td>
      <td>${e.fecha_ejecucion || ''}</td>
      <td>${e.proximo_vencimiento || ''}</td>
      <td>${e.responsable_text || ''}</td>
      <td>${e.descripcion || ''}</td>
      <td>${e.observaciones || ''}</td>
      <td>${e.adjunto_url || ''}</td>
      <td>
        <button class="btn btn-sm btn-warning me-2" data-act="edit" data-id="${e.id}">Editar</button>
        <button class="btn btn-sm btn-danger" data-act="del" data-id="${e.id}">Eliminar</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

document.getElementById('btnFiltrar').addEventListener('click', () =>
  listar().catch(() => showToast('Error al filtrar', 'error'))
);
document.getElementById('btnLimpiar').addEventListener('click', () => {
  $('q').value = '';
  $('fTipo').value = '';
  $('fPrioridad').value = '';
  $('fResultado').value = '';
  listar().catch(() => showToast('Error', 'error'));
});

btnNuevo.addEventListener('click', () => {
  $('title').textContent = 'Nuevo mantenimiento';
  $('id').value = '';
  $('equipoId').value = '';
  $('tipo').selectedIndex = 0;
  $('prioridad').selectedIndex = 0;
  $('resultado').selectedIndex = 0;
  modal.show();
});

tbody.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const { act, id } = btn.dataset;

  if (act === 'edit') {
    const it = await fetchJSON(`${API.man}/${id}`);
    $('title').textContent = `Editar mantenimiento #${id}`;
    $('id').value = id;
    $('equipoId').value = it.equipoId;
    $('tipo').value = it.tipo;
    $('prioridad').value = it.prioridad;
    $('resultado').value = it.resultado;
    $('fecha_programada').value = it.fecha_programada || '';
    $('fecha_ejecucion').value = it.fecha_ejecucion || '';
    $('proximo_vencimiento').value = it.proximo_vencimiento || '';
    $('responsable_text').value = it.responsable_text || '';
    $('descripcion').value = it.descripcion || '';
    $('observaciones').value = it.observaciones || '';
    $('adjunto_url').value = it.adjunto_url || '';
    modal.show();
  } else if (act === 'del') {
    if (!confirm('¿Eliminar mantenimiento?')) return;
    try {
      await fetchJSON(`${API.man}/${id}`, { method: 'DELETE' });
      await listar();
      showToast('Mantenimiento eliminado', 'info');
    } catch (e) {
      showToast('No se pudo eliminar', 'error');
    }
  }
});

document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    equipoId: Number($('equipoId').value),
    tipo: $('tipo').value,
    prioridad: $('prioridad').value,
    resultado: $('resultado').value,
    fecha_programada: $('fecha_programada').value,
    fecha_ejecucion: $('fecha_ejecucion').value,
    proximo_vencimiento: $('proximo_vencimiento').value,
    responsable_text: $('responsable_text').value,
    descripcion: $('descripcion').value,
    observaciones: $('observaciones').value,
    adjunto_url: $('adjunto_url').value,
  };
  const id = $('id').value;
  try {
    if (id)
      await fetchJSON(`${API.man}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    else
      await fetchJSON(API.man, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    modal.hide();
    await listar();
    showToast(id ? 'Mantenimiento actualizado' : 'Mantenimiento creado');
  } catch (e) {
    showToast('Error al guardar', 'error');
  }
});

(async function init() {
  try {
    await loadEnumsAndCatalogs();
    await listar();
  } catch (e) {
    console.error(e);
    showToast('Error de carga', 'error');
  }
})();
