// models/index.js
const Ubicacion = require('./Ubicacion');
const Responsable = require('./Responsable');
const { Equipo } = require('./Equipo');
const { Mantenimiento } = require('./Mantenimiento');


// Ubicación 1..N Equipos
Ubicacion.hasMany(Equipo, { foreignKey: 'ubicacionId' });
Equipo.belongsTo(Ubicacion, { foreignKey: 'ubicacionId' });

// Responsable 1..N Equipos
Responsable.hasMany(Equipo, { foreignKey: 'responsableId' });
Equipo.belongsTo(Responsable, { foreignKey: 'responsableId' });

// Equipo 1..N Mantenimientos
Equipo.hasMany(Mantenimiento, { foreignKey: 'equipoId', onDelete: 'CASCADE' });
Mantenimiento.belongsTo(Equipo, { foreignKey: 'equipoId' });

module.exports = { Ubicacion, Responsable, Equipo, Mantenimiento };