// models/Responsable.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../db');

// Campos solicitados: id, id_area, nombre_area
const Responsable = sequelize.define('Responsable', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  id_area: { type: DataTypes.STRING(50), allowNull: false, unique: true }, // código de área (único)
  nombre_area: { type: DataTypes.STRING(120), allowNull: false },
}, {
  tableName: 'responsables',
  timestamps: true,
});

module.exports = Responsable;
