// models/Product.js
const { DataTypes } = require('sequelize'); // tipos de datos
const { sequelize } = require('../db');   // instancia de Sequelize
const CATEGORIAS = ['Equipo IT', 'Equipo biomédico'];
const CONDICIONES = ['nuevo', 'usado'];

const Product = sequelize.define('Product', {
  id: {
    type: DataTypes.INTEGER.UNSIGNED, // UNSIGNED quiere decir sin negativos
    autoIncrement: true,
    primaryKey: true,
  },
  nombre: {
    type: DataTypes.STRING(100),
    allowNull: false,   // quiere decir NOT NULL, que es obligatorio
    validate: { notEmpty: true },
  },
  precio: {
    type: DataTypes.DECIMAL(10, 2), // 10 dígitos, 2 decimales
    allowNull: false,
    validate: { min: 0 },
  },
  // OJO: usamos STRING para no “congelar” las opciones en el modelo.
  // La restricción real sigue siendo ENUM en MySQL.
  categoria: { type: DataTypes.ENUM(...CATEGORIAS), allowNull: false },
  condicion: { type: DataTypes.ENUM(...CONDICIONES), allowNull: false, defaultValue: 'nuevo' },
}, {
  tableName: 'productos', // nombre de la tabla en la BD
  timestamps: true, // createdAt, updatedAt
});

module.exports = Product;
