// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { sequelize } = require('./db');
const Product = require('./models/Product');
const { readEnumValues } = require('./utils/enumReader');

const app = express();                   // ← crea la app 

// ----- EJS (SSR) -----
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ----- Middlewares globales -----
app.use(cors());
app.use(express.json());

//  Primero define la vista SSR (Server-Side Rendering) significa renderizado del lado del servidor)para "/"
app.get('/', (_req, res) => res.render('home'));

app.use(express.static('public'));       // ← carpeta pública para archivos estáticos (js, css, imágenes, etc)

// =======================
// Helper: fechas -> Bogotá 
// =======================
function fmtBogota(date) {
  return new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(date));
}
function toDTO(entity) {
  const obj = entity.toJSON ? entity.toJSON() : { ...entity };
  if (obj.createdAt) obj.createdAt = fmtBogota(obj.createdAt);
  if (obj.updatedAt) obj.updatedAt = fmtBogota(obj.updatedAt);


  // Fechas específicas de Mantenimiento
  if (obj.fecha_programada) obj.fecha_programada = fmtBogota(obj.fecha_programada);
  if (obj.fecha_ejecucion) obj.fecha_ejecucion = fmtBogota(obj.fecha_ejecucion);
  if (obj.proximo_vencimiento) obj.proximo_vencimiento = fmtBogota(obj.proximo_vencimiento);

  return obj;
}

// =====================================================================
// Rutas API REST (CRUD productos)
// =====================================================================

// ping / healthcheck (para Postman ): (health check endpoint) sirve para verificar que el servidor o la API están funcionando correctamente.
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

// Listar todos

app.get('/api/productos', async (_req, res) => {
  try {
    const productos = await Product.findAll({ order: [['id', 'ASC']] });
    res.json(productos.map(toDTO)); // mapea cada producto a un objeto plano con fechas formateadas, toDTO es la función de arriba que sirve para que se vea bien la fecha en Bogotá
  } catch (err) {
    res.status(500).json({ error: 'Error al listar productos' });
  }
});

// Obtener uno
app.get('/api/productos/:id', async (req, res) => {
  const prod = await Product.findByPk(req.params.id);
  if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json(toDTO(prod));
});

// Crear nuevo producto
app.post('/api/productos', async (req, res) => {
  try {
    const { nombre, precio, categoria, condicion } = req.body;
    if (!nombre || precio == null || !categoria || !condicion) {
      return res.status(400).json({ error: 'Faltan campos obligatorios' });
    }
    const nuevo = await Product.create({ nombre, precio, categoria, condicion });
    res.status(201).json(toDTO(nuevo));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Actualizar producto
app.put('/api/productos/:id', async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });

    const { nombre, precio, categoria, condicion } = req.body;
    await prod.update({ nombre, precio, categoria, condicion });
    res.json(toDTO(prod));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar producto
app.delete('/api/productos/:id', async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).json({ error: 'Producto no encontrado' });
    await prod.destroy();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

///   
// ===== Importamos los modelos
const { Op } = require('sequelize');
const { Ubicacion, Responsable, Equipo, Mantenimiento } = require('./models');  // ← agregamos el modelo Mantenimiento


// --- Opciones (ENUM de productos) ---
app.get('/api/opciones', async (_req, res) => {
  try {
    // nombres exactamente como en el modelo:
    // tableName: 'productos', columnas: 'categoria', 'condicion'
    const categorias  = await readEnumValues('productos', 'categoria');
    const condiciones = await readEnumValues('productos', 'condicion');
    res.json({ categorias, condiciones });
  } catch (e) {
    console.error('GET /api/opciones error:', e);
    res.status(500).json({ error: 'No se pudieron leer los catálogos' });
  }
});


// ======= Mantenimientos =======
app.get('/api/mantenimientos', async (req, res) => {
  try {
    const { tipo, prioridad, resultado, q } = req.query;
    const where = {};

    if (tipo) where.tipo = tipo;
    if (prioridad) where.prioridad = prioridad;
    if (resultado) where.resultado = resultado;

    if (q) {
      // Búsqueda libre por descripción o código de equipo
      where[Op.or] = [
        { descripcion: { [Op.like]: `%${q}%` } },
        { codigo_equipo: { [Op.like]: `%${q}%` } },
      ];
    }

    const items = await Mantenimiento.findAll({ where, order: [['id', 'ASC']] });
    res.json(items.map(toDTO));
  } catch (e) {
    console.error('Error al filtrar mantenimientos:', e);
    res.status(500).json({ error: 'Error al listar mantenimientos' });
  }
});


  app.get('/api/mantenimientos/:id', async (req, res) => {
    const item = await Mantenimiento.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Mantenimiento no encontrado' });
    res.json(toDTO(item));
  });

  app.post('/api/mantenimientos', async (req, res) => {
    try {
      const item = await Mantenimiento.create(req.body);
      res.status(201).json(toDTO(item));
    } catch (e) { res.status(400).json({ error: e.message }); }
  });

  app.put('/api/mantenimientos/:id', async (req, res) => {
    try {
      const item = await Mantenimiento.findByPk(req.params.id);
      if (!item) return res.status(404).json({ error: 'Mantenimiento no encontrado' });
      await item.update(req.body);
      res.json(toDTO(item));
    } catch (e) { res.status(400).json({ error: e.message }); }
  });

  app.delete('/api/mantenimientos/:id', async (req, res) => {
    try {
      const item = await Mantenimiento.findByPk(req.params.id);
      if (!item) return res.status(404).json({ error: 'Mantenimiento no encontrado' });
      await item.destroy();
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
  }); 


// =================== UBICACIONES ===================
app.get('/api/ubicaciones', async (_req, res) => {
  try {
    const items = await Ubicacion.findAll({ order: [['identificacion', 'ASC']] });
    res.json(items.map(toDTO));
  } catch (e) { res.status(500).json({ error: 'Error al listar ubicaciones' }); }
});

app.get('/api/ubicaciones/:id', async (req, res) => {
  const item = await Ubicacion.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
  res.json(toDTO(item));
});

app.post('/api/ubicaciones', async (req, res) => {
  try {
    const item = await Ubicacion.create(req.body);
    res.status(201).json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/ubicaciones/:id', async (req, res) => {
  try {
    const item = await Ubicacion.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/ubicaciones/:id', async (req, res) => {
  try {
    const hasEquipos = await Equipo.count({ where: { ubicacionId: req.params.id } });
    if (hasEquipos) return res.status(400).json({ error: 'No se puede eliminar: hay equipos en esta ubicación' });
    const item = await Ubicacion.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Ubicación no encontrada' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// =================== RESPONSABLES ===================
app.get('/api/responsables', async (_req, res) => {
  try {
    const items = await Responsable.findAll({ order: [['id_area', 'ASC']] });
    res.json(items.map(toDTO));
  } catch (e) { res.status(500).json({ error: 'Error al listar responsables' }); }
});

app.get('/api/responsables/:id', async (req, res) => {
  const item = await Responsable.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
  res.json(toDTO(item));
});

app.post('/api/responsables', async (req, res) => {
  try {
    const item = await Responsable.create(req.body);
    res.status(201).json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/responsables/:id', async (req, res) => {
  try {
    const item = await Responsable.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/responsables/:id', async (req, res) => {
  try {
    const hasEquipos = await Equipo.count({ where: { responsableId: req.params.id } });
    if (hasEquipos) return res.status(400).json({ error: 'No se puede eliminar: hay equipos asociados a este responsable' });
    const item = await Responsable.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Responsable no encontrado' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// =================== EQUIPOS ===================
app.get('/api/equipos', async (req, res) => {
  try {
    const { q, estado, tipo, ubicacionId, responsableId } = req.query;
    const where = {};
    if (estado) where.estado = estado;
    if (tipo) where.tipo_equipo = tipo;
    if (ubicacionId) where.ubicacionId = Number(ubicacionId);
    if (responsableId) where.responsableId = Number(responsableId);
    if (q) {
      // Buscar por código exacto o like en serial/marca/modelo
      where[Op.or] = [
        { codigo_inventario: q },
        { serial: { [Op.like]: `%${q}%` } },
        { marca:  { [Op.like]: `%${q}%` } },
        { modelo: { [Op.like]: `%${q}%` } },
      ];
    }

    const items = await Equipo.findAll({
      where,
      include: [Ubicacion, Responsable],
      order: [['id', 'ASC']]
    });
    res.json(items.map(toDTO));
  } catch (e) { res.status(500).json({ error: 'Error al listar equipos' }); }
});

app.get('/api/equipos/:id', async (req, res) => {
  const item = await Equipo.findByPk(req.params.id, { include: [Ubicacion, Responsable] });
  if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
  res.json(toDTO(item));
});

app.post('/api/equipos', async (req, res) => {
  try {
    const item = await Equipo.create(req.body);
    res.status(201).json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/equipos/:id', async (req, res) => {
  try {
    const item = await Equipo.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
    await item.update(req.body);
    res.json(toDTO(item));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/equipos/:id', async (req, res) => {
  try {
    const item = await Equipo.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Equipo no encontrado' });
    await item.destroy();
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

///


////------------Renderizado del frontend con EJS / ssr-----------------
// ===== Rutas de VISTAS (SSR con EJS) =====


// Productos (lista SSR)
app.get('/productos', async (_req, res) => {
  const productos = await Product.findAll({ order: [['id','ASC']] });
  res.render('productos', { productos: productos.map(toDTO) });
});


// Equipos (lista SSR)
app.get('/equipos', async (_req, res) => {
  const equipos = await Equipo.findAll({ include: [Ubicacion, Responsable], order: [['id','ASC']] });
  res.render('equipos', { equipos });
});

// Ubicaciones (lista SSR)
app.get('/ubicaciones', async (_req, res) => {
  const ubicaciones = await Ubicacion.findAll({ order: [['identificacion', 'ASC']] });
  res.render('ubicaciones', { ubicaciones });
});

// Responsables (lista SSR)
app.get('/responsables', async (_req, res) => {
  const responsables = await Responsable.findAll({ order: [['id_area', 'ASC']] });
  res.render('responsables', { responsables });
});

//mantenimientos (lista SSR)
app.get('/mantenimientos', async (_req, res) => {
  const mantenimientos = await Mantenimiento.findAll({ order: [['id','ASC']] });
  res.render('mantenimientos', { mantenimientos });
  });
  


/// -------------------------------

// =======================
// Arranque de la app con BD 
// =======================
const PORT = Number(process.env.PORT || 4000);

(async () => {  // IIFE asíncrona para poder usar await en el arranque, await es como un try/catch pero que sirve para promesas, es decir asíncrono
  try {
    await sequelize.authenticate(); // probar conexión a la BD
    console.log('Conectado a la BD MySQL');

    // Crea tablas si no existen 
    await sequelize.sync();
    console.log('Tablas listas');

    // ---- SEED AUTOMÁTICO SI ESTÁ VACÍO ----
    const total = await Product.count();
    if (total === 0) {
      await Product.bulkCreate([
        { nombre: 'Router',           precio: 299900,  categoria: 'Equipo IT',        condicion: 'nuevo' },
        { nombre: 'Portátil 15” i9',  precio: 7399900, categoria: 'Equipo IT',        condicion: 'nuevo' },
        { nombre: 'Bomba infusora',   precio: 1299900, categoria: 'Equipo biomédico', condicion: 'usado' },
      ]);
      console.log('Seed inicial cargado (3 productos).');
    }
    // ---------------------------------------

///-------- SEED No.2

const uCount = await Ubicacion.count();
if (!uCount) {
  await Ubicacion.bulkCreate([
    { identificacion:'S1-A-3-305', sede:'Sede 1', edificio:'A', piso:'3', sala:'305' },
    { identificacion:'S1-D-1-101', sede:'Sede 1', edificio:'D', piso:'1', sala:'101' },
  ]);
}

const rCount = await Responsable.count();
if (!rCount) {
  await Responsable.bulkCreate([
    { id_area:'TI', nombre_area:'Tecnologías de la Información' },
    { id_area:'LOG', nombre_area:'Logística' },
  ]);
}

const [u1] = await Ubicacion.findAll({ limit:1 });
const [r1] = await Responsable.findAll({ limit:1 });

const eCount = await Equipo.count();
if (!eCount && u1 && r1) {
  await Equipo.bulkCreate([
    { codigo_inventario:'EQ-0001', serial:'SN-ABC-001', marca:'Dell', modelo:'Latitude 5520', tipo_equipo:'laptop', estado:'operativo', ubicacionId:u1.id, responsableId:r1.id },
    { codigo_inventario:'EQ-0002', serial:'SN-XYZ-002', marca:'HP',   modelo:'ProDesk 600',   tipo_equipo:'desktop', estado:'operativo', ubicacionId:u1.id, responsableId:r1.id },
  ]);
}


///----------------------



    app.listen(PORT, () => {
      console.log(`Servidor listo → http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('No se pudo iniciar:', err);
    process.exit(1);
  }
})(); // IIFE (Immediately Invoked Function Expression) asíncrona para poder usar await en el arranque

