// ==========================
// Tema (persistente con localStorage)
// ==========================

// Clave en localStorage para guardar el tema
const THEME_KEY = "theme";
// Selecciona todos los íconos de cambio de tema
const themeIcons = document.querySelectorAll(".theme-icon");

// Obtiene el tema guardado en localStorage o "light" por defecto
const savedTheme = localStorage.getItem(THEME_KEY) || "light";
// Aplica el tema al body (className = "light" o "dark")
document.body.className = savedTheme;

// Marca como activo el icono que corresponde al tema actual
themeIcons.forEach((icon) => {
  icon.classList.toggle("active", icon.dataset.theme === savedTheme);
});

// Agrega eventos a cada icono para cambiar el tema al hacer clic
themeIcons.forEach((icon) => {
  icon.addEventListener("click", () => {
    const theme = icon.dataset.theme;
    // Cambia la clase del body
    document.body.className = theme;
    // Guarda el tema en localStorage
    localStorage.setItem(THEME_KEY, theme);

    // Marca el icono seleccionado como activo
    themeIcons.forEach((i) => i.classList.remove("active"));
    icon.classList.add("active");
  });
});

// ==========================
// Estado + Persistencia
// ==========================

// Clave en localStorage para guardar pacientes
const STORAGE_KEY = "pacientes_app_v1";

let pacientes = []; // Array donde se guardan los pacientes
let editModal; // Variable para manejar el modal de edición

// ==========================
// Utilidades
// ==========================

// Muestra mensajes (alertas de Bootstrap)
function showMessage(text, type = "info", timeout = 3000) {
  const cont = document.getElementById("msg");
  cont.innerHTML = `
    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
      ${text}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
  `;
  // Se cierra automáticamente después del tiempo indicado
  if (timeout) {
    setTimeout(() => {
      const alertEl = cont.querySelector(".alert");
      if (alertEl) bootstrap.Alert.getOrCreateInstance(alertEl).close();
    }, timeout);
  }
}
// Cargar pacientes desde localStorage (si existen)
function loadPacientes() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    pacientes = raw ? JSON.parse(raw) : []; // Si no hay nada → []
    if (!Array.isArray(pacientes)) pacientes = []; // Seguridad
  } catch {
    pacientes = []; // Si hay error en JSON → lista vacía
  }
}

// Guardar pacientes en localStorage
function savePacientes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientes));
}


function isValidId(id) {
  return /^[A-Za-z0-9]+$/.test(id || "");
}
function existsId(id, excludeId = null) {
  const nid = id.trim().toLowerCase();
  const ex = excludeId ? excludeId.trim().toLowerCase() : null;
  return pacientes.some(p => p.id.toLowerCase() === nid && (ex ? p.id.toLowerCase() !== ex : true));
}


// Crea un objeto paciente validando datos
function crearPaciente(id, nombre, apellido, edad, motivo) {
  const e = Number(edad);
  if (!id || !nombre || !apellido || Number.isNaN(e) || e <= 0) return null;
  return {
    id: id.trim(),
    nombre: nombre.trim(),
    apellido: apellido.trim(),
    edad: e,
    motivo: motivo.trim(),
  };
}

// Calcula promedio de edades
function promedioEdad(arr) {
  if (arr.length === 0) return 0;
  let suma = 0;
  for (const p of arr) suma += p.edad;
  return Math.round((suma / arr.length) * 100) / 100;
}

// Aplica filtros a la lista de pacientes y devuelve la lista filtrada
let filterText = "";
let filterStatus = "all";
let minEdad = null, maxEdad = null;

function getViewData() {
  return pacientes.filter(p => {
    const q = (filterText || "").toLowerCase();
    const matchText =
      !q ||
      p.id.toLowerCase().includes(q) ||
      p.nombre.toLowerCase().includes(q) ||
      p.apellido.toLowerCase().includes(q) ||
      p.motivo.toLowerCase().includes(q);

    const matchMin = minEdad == null || p.edad >= minEdad;
    const matchMax = maxEdad == null || p.edad <= maxEdad;
    const matchMotivo = currentMotivo === "all" || p.motivo === currentMotivo;

    return matchText && matchMin && matchMax && matchMotivo;
  });
}

function renderTabla() {
  const tbody = document.getElementById("tbody");
  tbody.innerHTML = "";

  let view = getViewData();

  // Ordenar
  view.sort((a, b) => {
    switch (currentSort) {
      case "id-asc": return a.id.localeCompare(b.id);
      case "id-desc": return b.id.localeCompare(a.id);
      case "nombre-asc": return a.nombre.localeCompare(b.nombre);
      case "nombre-desc": return b.nombre.localeCompare(a.nombre);
      case "apellido-asc": return a.apellido.localeCompare(b.apellido);
      case "apellido-desc": return b.apellido.localeCompare(a.apellido);
      case "edad-asc": return a.edad - b.edad;
      case "edad-desc": return b.edad - a.edad;
      default: return 0;
    }
  });

  view.forEach((p, idx) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${idx + 1}</td>
      <td>${p.nombre}</td>
      <td>${p.apellido}</td>
      <td>${p.id}</td>
      <td>${p.edad}</td>
      <td class="${p.edad >= 18 ? "text-success fw-bold" : "text-danger fw-bold"}">
        ${p.edad >= 18 ? "Mayor" : "Menor"}
      </td>
      <td>${p.motivo}</td>
      <td>
        <div class="btn-group btn-group-sm">
          <button type="button" class="btn btn-outline-primary btn-edit" data-idx="${pacientes.indexOf(p)}">Editar</button>
          <button type="button" class="btn btn-outline-danger btn-del" data-idx="${pacientes.indexOf(p)}">Eliminar</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Eventos
  tbody.querySelectorAll(".btn-edit").forEach((btn) =>
    btn.addEventListener("click", (e) =>
      abrirModalEdicion(Number(e.currentTarget.dataset.idx))
    )
  );
  tbody.querySelectorAll(".btn-del").forEach((btn) =>
    btn.addEventListener("click", (e) =>
      eliminar(Number(e.currentTarget.dataset.idx))
    )
  );

  renderStats();
}

// ==========================
// Renderiza estadísticas generales
// ==========================
function renderStats() {
  const cont = document.getElementById("stats");
  const view = getViewData(); // ✅ usar lista filtrada
  const total = view.length;
  const mayores = view.filter((p) => p.edad >= 18).length;
  const menores = view.filter((p) => p.edad < 18).length;
  const prom = promedioEdad(view);

  cont.innerHTML = `
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Total consultas</div>
        <div class="display-6">${total}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Mayores de edad</div>
        <div class="display-6 text-success">${mayores}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Menores de edad</div>
        <div class="display-6 text-danger">${menores}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Promedio edad</div>
        <div class="display-6">${prom}</div>
      </div></div>
    </div>`;
}
// ==========================
// CRUD
// ==========================
 const formPac = document.getElementById("formPaciente");
const newIdInput = document.getElementById("id");
const newIdFeedback = document.getElementById("newIdFeedback");

function validateNewId(showFeedback = false) {
  const id = newIdInput.value.trim().toLowerCase(); // Limpiamos y conviertamos a minúsculas
  const addBtn = formPac?.querySelector("button[type='submit']"); // Obtenemos botón de guardarEdicion
  if (id === "") { // Si el ID es vacío
    if (showFeedback) { // Mostramos feedback si se desea mostrar feedback      
      newIdInput.classList.add("is-invalid"); // Agregamos clase de error
      newIdFeedback.textContent = "El ID es obligatorio."; // Mostramos feedback
      addBtn.disabled = true; // Deshabilitamos botón de agregar
      return false; // Devolvemos falso
    } else { // Si no se desea mostrar feedback
      newIdInput.classList.remove("is-invalid"); // Quitamos clase de error
      newIdFeedback.textContent = ""; // Limpiamos feedback
      addBtn.disabled = false; // Habilitamos botón de agregar
      return true; // Devolvemos verdadero

    }
  }
  if (!isValidId(id)) { // Si el ID no es válido
    newIdInput.classList.add("is-invalid"); // Agregamos clase de error
    newIdFeedback.textContent = "El ID debe contener solo letras y números."; // Mostramos feedback
    addBtn.disabled = true; // Deshabilitamos botón de agregar
    return false; // Devolvemos falso
    
  }  
  if (existsId(id)) { // Si el ID existe
    newIdInput.classList.add("is-invalid"); // Agregamos clase de error
    newIdFeedback.textContent = `El ID "${id}" ya existe.`; // Mostramos feedback
    addBtn.disabled = true; // Deshabilitamos botón de agregar
    return false; // Devolvemos falso 
  } 
  newIdInput.classList.remove("is-invalid"); // Quitamos clase de errori
  newIdFeedback.textContent = ""; // Limpiamos feedback
  addBtn.disabled = false; // Habilitamos botón de agregar
  return true; // Devolvemos verdadero
}
["input", "blur"].forEach(ev => newIdInput.addEventListener(ev, () => validateNewId(false))); // Listener para validar nuevo ID en entrada

function agregar(evt) {
  evt.preventDefault(); // Evita recargar la página
  if (!validateNewId(true)) return showMessage("Verifica: identificación", "warning");
  // Obtenemos valores del formulario
  const id = document.getElementById("id").value;
  const nombre = document.getElementById("nombre").value;
  const apellido = document.getElementById("apellido").value;
  const edad = document.getElementById("edad").value;
  const motivo = document.getElementById("reason").value;

  // Creamos objeto paciente
  const nuevo = crearPaciente(id, nombre, apellido, edad, motivo);
  if (!nuevo) return showMessage("Verifica: identificación, nombre, apellido y edad válidos.","warning");
  // Lo agregamos al array
  pacientes.push(nuevo);
  savePacientes(); // Guardamos en localStorage
  evt.target.reset(); // Limpiamos formulario
  newIdInput.classList.remove("is-invalid"); // Quitamos clase de error
  newIdFeedback.textContent = ""; // Limpiamos feedback
  renderTabla(); // Renderizamos tabla
  showMessage("Paciente agregado.", "success", 1800);
}

// Eliminar paciente según índice
function eliminar(idx) {
  pacientes.splice(idx, 1); // Quitamos del array el paciente en esa posición
  savePacientes(); // Actualizamos localStorage
  renderTabla(); // Actualizamos la tabla
  showMessage("Registro eliminado.", "info", 1500);
}

// ==========================
// Edición con Modal
// ==========================
function abrirModalEdicion(idx) {
  const p = pacientes[idx];
  if (!p) return;

  // Guardar índice en input oculto
  document.getElementById("editIndex").value = idx;

  // Rellenar los campos del modal
  document.getElementById("editId").value = p.id;
  document.getElementById("editNombre").value = p.nombre;
  document.getElementById("editApellido").value = p.apellido;
  document.getElementById("editEdad").value = p.edad;
  document.getElementById("editReason").value = p.motivo;

  // Guardar el ID original para validar duplicados correctamente
  document.getElementById("editId").dataset.origId = p.id;

  if (!editModal)
    editModal = new bootstrap.Modal(document.getElementById("editModal"));
  editModal.show();
}

// Guardar cambios del modal
function guardarEdicion(evt) {
  evt.preventDefault();

  const idx = Number(document.getElementById("editIndex").value);
  const editIdEl = document.getElementById("editId");
  const origId = editIdEl.dataset.origId; // ✅ ID original

  // Nuevos valores
  const id = editIdEl.value.trim();
  const nombre = document.getElementById("editNombre").value.trim();
  const apellido = document.getElementById("editApellido").value.trim();
  const edad = document.getElementById("editEdad").value;
  const motivo = document.getElementById("editReason").value;

  // Validaciones
  if (!isValidId(id)) return showMessage("ID inválido.", "warning");

  // Solo validar duplicados si cambió el ID
  if (id !== origId && existsId(id)) {
    return showMessage(`Ya existe otro paciente con ID "${id}".`, "warning");
  }

  // Crear objeto validado
  const actualizado = crearPaciente(id, nombre, apellido, edad, motivo);
  if (!actualizado) return showMessage("Datos inválidos en edición.", "warning");

  // Actualizar array y refrescar tabla
  pacientes[idx] = actualizado;
  savePacientes();
  renderTabla();
  if (editModal) editModal.hide();
  showMessage("Cambios guardados.", "success", 1800);
}
// ==========================
// Listeners base
// ==========================

// Evento para agregar paciente
document.getElementById("formEdit").addEventListener("submit", guardarEdicion); 

// Botón para limpiar toda la lista de pacientes agregados
document.getElementById("btnLimpiar").addEventListener("click", () => {
  if (confirm("¿Seguro que deseas limpiar la lista?")) {
    pacientes = [];
    savePacientes();
    renderTabla();
    showMessage("Lista limpiada.", "secondary", 1500);
  }
});
// ==========================
// Botón demo (corregido)
// ==========================
document.getElementById("btnDemo").addEventListener("click", () => {
  pacientes = [
    { id: "1116182054", nombre: "Juan", apellido: "Pérez", edad: 30, motivo: "General" },
    { id: "1116182055", nombre: "Ana", apellido: "Rodríguez", edad: 17, motivo: "Odontología" },
    { id: "1116182056", nombre: "Luis", apellido: "Marquez", edad: 15, motivo: "Pediatría" },
    { id: "1116182057", nombre: "Marta", apellido: "Alfonso", edad: 25, motivo: "Urgencias" },
    { id: "1116182058", nombre: "Pedro", apellido: "Mendoza", edad: 21, motivo: "Pediatría" },
    { id: "1116182059", nombre: "Lucía", apellido: "Ramirez", edad: 22, motivo: "Odontología" },
    { id: "1116182060", nombre: "Daniel", apellido: "Hernandez", edad: 50, motivo: "General" },
  ];
  savePacientes(); // ✅ función correcta
  renderTabla();
  showMessage("Datos de demostración cargados.", "secondary", 1500);
});

// Exportar / Importar
document.getElementById("btnExportCSV").addEventListener("click", exportCSV);
document.getElementById("btnExportJSON").addEventListener("click", exportJSON);
document
  .getElementById("btnPlantilla")
  .addEventListener("click", descargarPlantillaCSV);

// Botón de importar archivo
document.getElementById("btnImport").addEventListener("click", () => {
  document.getElementById("fileImport").click();
});
document
  .getElementById("fileImport")
  .addEventListener("change", importarArchivo);
// === Listeners de filtros ===

// Inputs
const searchInput = document.getElementById("searchInput");
const minEdadInput = document.getElementById("minEdadInput");
const maxEdadInput = document.getElementById("maxEdadInput");
const motivoSelect = document.getElementById("motivoSelect");
const sortSelect = document.getElementById("sortSelect");
const btnClearFilters = document.getElementById("btnClearFilters");

let currentMotivo = "all";
let currentSort = "id-asc";

// Escuchar búsqueda
searchInput.addEventListener("input", () => {
  filterText = searchInput.value.trim().toLowerCase();
  renderTabla();
});

// Escuchar edad mínima
minEdadInput.addEventListener("input", () => {
  minEdad = minEdadInput.value ? Number(minEdadInput.value) : null;
  renderTabla();
});

// Escuchar edad máxima
maxEdadInput.addEventListener("input", () => {
  maxEdad = maxEdadInput.value ? Number(maxEdadInput.value) : null;
  renderTabla();
});

// Escuchar motivo
motivoSelect.addEventListener("change", () => {
  currentMotivo = motivoSelect.value;
  renderTabla();
});

// Escuchar ordenamiento
sortSelect.addEventListener("change", () => {
  currentSort = sortSelect.value;
  renderTabla();
});

// Botón limpiar filtros
btnClearFilters.addEventListener("click", () => {
  searchInput.value = "";
  minEdadInput.value = "";
  maxEdadInput.value = "";
  motivoSelect.value = "all";
  sortSelect.value = "id-asc";

  filterText = "";
  minEdad = null;
  maxEdad = null;
  currentMotivo = "all";
  currentSort = "id-asc";

  renderTabla();
});
// Cada vez que cambias un filtro se vuelve a renderizar la tabla
document.getElementById("filtersForm").addEventListener("input", renderTabla);
// Botón "Limpiar filtros" → resetea formulario y recarga tabla sin filtros
document.getElementById("btnClearFilters").addEventListener("click", (e) => {
  e.preventDefault();
  document.getElementById("filtersForm").reset();
  renderTabla();
});

// ==========================
// Exportar / Importar CSV & JSON
// ==========================

// Exportar a CSV
function exportCSV() {
  if (pacientes.length === 0) {
    showMessage("No hay datos para exportar.", "warning");
    return;
  }
  const header = ["Identificacion", "Nombre", "Apellido", "Edad", "Motivo"];
  const rows = pacientes.map((p) => [
    p.id,
    p.nombre,
    p.apellido,
    p.edad,
    p.motivo,
  ]);
  const csvContent = [header, ...rows].map((r) => r.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pacientes.csv";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("CSV exportado.", "success", 1500);
}

// Exportar a JSON
function exportJSON() {
  if (pacientes.length === 0) {
    showMessage("No hay datos para exportar.", "warning");
    return;
  }
  const blob = new Blob([JSON.stringify(pacientes, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pacientes.json";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("JSON exportado.", "success", 1500);
}

// Descargar plantilla CSV de ejemplo
function descargarPlantillaCSV() {
  const header = ["Identificación", "Nombre", "Apellido", "Edad", "Motivo"];
  const ejemplo = [" 1234567", "Ana", "Pérez", "25", "General"];
  const csvContent = [header, ejemplo].map((r) => r.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "plantilla_pacientes.csv";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("Plantilla CSV descargada.", "info", 1500);
}

// Importar archivo (JSON o CSV)
function importarArchivo(evt) {
  const file = evt.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      let imported = [];
      if (file.name.endsWith(".json")) {
        imported = JSON.parse(e.target.result);
      } else if (file.name.endsWith(".csv")) {
        const lines = e.target.result
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean);
        imported = lines
          .slice(1)
          .map((line) => {
            const [id, nombre, apellido, edad, motivo] = line.split(",");
            return crearPaciente(id, nombre, apellido, edad, motivo);
          })
          .filter(Boolean);
      }

      if (imported.length > 0) {
        pacientes = pacientes.concat(imported);
        savePacientes();
        renderTabla();
        showMessage(
          `${imported.length} registros importados.`,
          "success",
          2000
        );
      } else {
        showMessage("El archivo no contenía datos válidos.", "warning");
      }
    } catch (err) {
      showMessage("Error al importar: " + err.message, "danger");
    }
  };
  reader.readAsText(file);
}
// ==========================
// Estado inicial
// ==========================

// Carga los pacientes almacenados y renderiza tabla
loadPacientes();
renderTabla();
