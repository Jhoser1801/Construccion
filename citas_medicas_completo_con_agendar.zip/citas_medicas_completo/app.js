// ==========================
// Tema (persistente con localStorage)
// ==========================

// Clave en localStorage para guardar el tema
const THEME_KEY = "theme";
// Selecciona todos los íconos de cambio de tema
const themeIcons = document.querySelectorAll(".theme-icon");

// Obtiene el tema guardado en localStorage o "light" por defecto
const savedTheme = localStorage.getItem(THEME_KEY) || "light";
// Aplica el tema al body (className = "light" o "dark")
document.body.className = savedTheme;

// Marca como activo el icono que corresponde al tema actual
themeIcons.forEach(icon => {
  icon.classList.toggle("active", icon.dataset.theme === savedTheme);
});

// Agrega eventos a cada icono para cambiar el tema al hacer clic
themeIcons.forEach(icon => {
  icon.addEventListener("click", () => {
    const theme = icon.dataset.theme;
    // Cambia la clase del body
    document.body.className = theme;
    // Guarda el tema en localStorage
    localStorage.setItem(THEME_KEY, theme);

    // Marca el icono seleccionado como activo
    themeIcons.forEach(i => i.classList.remove("active"));
    icon.classList.add("active");
  });
});

// ==========================
// Estado + Persistencia
// ==========================

// Clave en localStorage para guardar pacientes
const STORAGE_KEY = "pacientes_app_v1";

let pacientes = []; // Array donde se guardan los pacientes
let editModal;      // Variable para manejar el modal de edición

// Cargar pacientes desde localStorage
function loadPacientes() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    pacientes = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(pacientes)) pacientes = [];
  } catch {
    pacientes = [];
  }
}

// Guardar pacientes en localStorage
function savePacientes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(pacientes));
}

// ==========================
// Utilidades
// ==========================

// Muestra mensajes (alertas de Bootstrap)
function showMessage(text, type = "info", timeout = 3000) {
  const cont = document.getElementById("msg");
  cont.innerHTML = `
    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
      ${text}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
  `;
  // Se cierra automáticamente después del tiempo indicado
  if (timeout) {
    setTimeout(() => {
      const alertEl = cont.querySelector(".alert");
      if (alertEl) bootstrap.Alert.getOrCreateInstance(alertEl).close();
    }, timeout);
  }
}

// Crea un objeto paciente validando datos
function crearPaciente(nombre, apellido, edad, motivo) {
  const e = Number(edad);
  if (!nombre || !apellido || Number.isNaN(e) || e <= 0) return null;
  return { nombre: nombre.trim(), apellido: apellido.trim(), edad: e, motivo: motivo.trim() };
}

// Calcula promedio de edades
function promedioEdad(arr) {
  if (arr.length === 0) return 0;
  let suma = 0;
  for (const p of arr) suma += p.edad;
  return Math.round((suma / arr.length) * 100) / 100;
}

// ==========================
// Render tabla y stats
// ==========================

// Renderiza la tabla de pacientes
const renderTabla = () => {
  const tbody = document.getElementById("tbody");
  tbody.innerHTML = "";

  pacientes.forEach((p, idx) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${idx + 1}</td>
      <td>${p.nombre}</td>
      <td>${p.apellido}</td>
      <td>${p.edad}</td>
      <td>${p.edad >= 18 ? "Mayor" : "Menor"}</td>
      <td>${p.motivo}</td>
      <td>
        <div class="btn-group btn-group-sm">
          <button type="button" class="btn btn-outline-primary btn-edit" data-idx="${idx}">Editar</button>
          <button type="button" class="btn btn-outline-danger btn-del" data-idx="${idx}">Eliminar</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Eventos para los botones de editar y eliminar
  tbody.querySelectorAll(".btn-edit").forEach(btn =>
    btn.addEventListener("click", (e) => abrirModalEdicion(Number(e.currentTarget.dataset.idx)))
  );
  tbody.querySelectorAll(".btn-del").forEach(btn =>
    btn.addEventListener("click", (e) => eliminar(Number(e.currentTarget.dataset.idx)))
  );

  renderStats(); // Actualiza estadísticas
};

// Renderiza estadísticas generales
const renderStats = () => {
  const cont = document.getElementById("stats");
  const total = pacientes.length;
  const mayores = pacientes.filter(p => p.edad >= 18).length;
  const menores = total - mayores;
  const prom = promedioEdad(pacientes);

  cont.innerHTML = `
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Total consultas</div>
        <div class="display-6">${total}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Mayores de edad</div>
        <div class="display-6 text-success">${mayores}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Menores de edad</div>
        <div class="display-6 text-danger">${menores}</div>
      </div></div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100"><div class="card-body">
        <div class="fw-semibold text-secondary">Promedio edad</div>
        <div class="display-6">${prom}</div>
      </div></div>
    </div>
  `;
};

// ==========================
// CRUD
// ==========================

// Agregar paciente nuevo
const agregar = (evt) => {
  evt.preventDefault(); // Evita que se recargue la página
  const nombre = document.getElementById("nombre").value;
  const apellido = document.getElementById("apellido").value;
  const edad = document.getElementById("edad").value;
  const motivo = document.getElementById("reason").value; // id corregido

  const nuevo = crearPaciente(nombre, apellido, edad, motivo);
  if (!nuevo) {
    showMessage("Verifica: nombre, apellido y edad válidos.", "warning");
    return;
  }
  pacientes.push(nuevo);
  savePacientes();
  evt.target.reset(); // Limpia formulario
  document.getElementById("nombre").focus();
  renderTabla();
  showMessage("Paciente agregado.", "success", 1800);
};

// Eliminar paciente por índice
function eliminar(idx) {
  pacientes.splice(idx, 1);
  savePacientes();
  renderTabla();
  showMessage("Registro eliminado.", "info", 1500);
}

// ==========================
// Edición con Modal
// ==========================

// Abre el modal con datos del paciente
function abrirModalEdicion(idx) {
  const p = pacientes[idx];
  if (!p) return;

  document.getElementById("editIndex").value = idx;
  document.getElementById("editNombre").value = p.nombre;
  document.getElementById("editApellido").value = p.apellido;
  document.getElementById("editEdad").value = p.edad;
  document.getElementById("editReason").value = p.motivo;

  if (!editModal) editModal = new bootstrap.Modal(document.getElementById("editModal"));
  editModal.show();
}

// Guardar cambios del modal
function guardarEdicion(evt) {
  evt.preventDefault();
  const idx = Number(document.getElementById("editIndex").value);
  const nombre = document.getElementById("editNombre").value;
  const apellido = document.getElementById("editApellido").value;
  const edad = document.getElementById("editEdad").value;
  const motivo = document.getElementById("editReason").value;

  const actualizado = crearPaciente(nombre, apellido, edad, motivo);
  if (!actualizado) {
    showMessage("Datos inválidos en edición.", "warning");
    return;
  }

  pacientes[idx] = actualizado;
  savePacientes();
  renderTabla();
  editModal.hide();
  showMessage("Cambios guardados.", "success", 1800);
}

// ==========================
// Exportar / Importar CSV & JSON
// ==========================

// Exportar a CSV
function exportCSV() {
  if (pacientes.length === 0) {
    showMessage("No hay datos para exportar.", "warning");
    return;
  }
  const header = ["Nombre", "Apellido", "Edad", "Motivo"];
  const rows = pacientes.map(p => [p.nombre, p.apellido, p.edad, p.motivo]);
  const csvContent = [header, ...rows].map(r => r.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pacientes.csv";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("CSV exportado.", "success", 1500);
}

// Exportar a JSON
function exportJSON() {
  if (pacientes.length === 0) {
    showMessage("No hay datos para exportar.", "warning");
    return;
  }
  const blob = new Blob([JSON.stringify(pacientes, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pacientes.json";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("JSON exportado.", "success", 1500);
}

// Descargar plantilla CSV de ejemplo
function descargarPlantillaCSV() {
  const header = ["Nombre", "Apellido", "Edad", "Motivo"];
  const ejemplo = ["Ana", "Pérez", "25", "General"];
  const csvContent = [header, ejemplo].map(r => r.join(",")).join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "plantilla_pacientes.csv";
  a.click();
  URL.revokeObjectURL(url);
  showMessage("Plantilla CSV descargada.", "info", 1500);
}

// Importar archivo (JSON o CSV)
function importarArchivo(evt) {
  const file = evt.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      let imported = [];
      if (file.name.endsWith(".json")) {
        imported = JSON.parse(e.target.result);
      } else if (file.name.endsWith(".csv")) {
        const lines = e.target.result.split("\n").map(l => l.trim()).filter(Boolean);
        imported = lines.slice(1).map(line => {
          const [nombre, apellido, edad, motivo] = line.split(",");
          return crearPaciente(nombre, apellido, edad, motivo);
        }).filter(Boolean);
      }

      if (imported.length > 0) {
        pacientes = pacientes.concat(imported);
        savePacientes();
        renderTabla();
        showMessage(`${imported.length} registros importados.`, "success", 2000);
      } else {
        showMessage("El archivo no contenía datos válidos.", "warning");
      }
    } catch (err) {
      showMessage("Error al importar: " + err.message, "danger");
    }
  };
  reader.readAsText(file);
}

// ==========================
// Listeners base
// ==========================

// Evento para agregar paciente
document.getElementById("formPaciente").addEventListener("submit", agregar);

// Botón para limpiar toda la lista
document.getElementById("btnLimpiar").addEventListener("click", () => {
  if (confirm("¿Seguro que deseas limpiar la lista?")) {
    pacientes = [];
    savePacientes();
    renderTabla();
    showMessage("Lista limpiada.", "secondary", 1500);
  }
});

// Evento para guardar cambios de edición
document.getElementById("formEdit").addEventListener("submit", guardarEdicion);

// Exportar / Importar
document.getElementById("btnExportCSV").addEventListener("click", exportCSV);
document.getElementById("btnExportJSON").addEventListener("click", exportJSON);
document.getElementById("btnPlantilla").addEventListener("click", descargarPlantillaCSV);

// Botón de importar archivo
document.getElementById("btnImport").addEventListener("click", () => {
  document.getElementById("fileImport").click();
});
document.getElementById("fileImport").addEventListener("change", importarArchivo);

// ==========================
// Estado inicial
// ==========================

// Carga los pacientes almacenados y renderiza tabla
loadPacientes();
renderTabla();
